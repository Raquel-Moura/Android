package com.example.loginlinear

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActiviryLogin : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activiry_login)
    }
}